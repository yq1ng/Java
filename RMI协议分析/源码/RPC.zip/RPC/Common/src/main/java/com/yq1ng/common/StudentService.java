package com.yq1ng.common;

public interface StudentService {
    User findStudentById(Integer id);
    User findStudentByName(String name);
}
