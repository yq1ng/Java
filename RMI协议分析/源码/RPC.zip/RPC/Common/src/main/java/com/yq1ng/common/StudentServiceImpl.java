package com.yq1ng.common;

public class StudentServiceImpl {

    public User findStudentById(Integer id) {
        //  代码简化，实际生产应查询数据库
        return new User(id, "yq1ng");
    }

    public User findStudentByName(String name) {
        return new User(666, name);
    }

}
