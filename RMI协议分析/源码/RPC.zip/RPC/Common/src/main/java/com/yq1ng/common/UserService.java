package com.yq1ng.common;

public interface UserService {
    User findUserById(Integer id);
    User findUserByName(String name);
}
