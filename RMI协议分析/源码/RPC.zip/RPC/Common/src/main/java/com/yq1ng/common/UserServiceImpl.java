package com.yq1ng.common;

import com.yq1ng.common.User;
import com.yq1ng.common.UserService;

public class UserServiceImpl implements UserService {

    public User findUserById(Integer id) {
        //  代码简化，实际生产应查询数据库
        return new User(id, "yq1ng");
    }

    public User findUserByName(String name) {
        return new User(666, name);
    }
}
