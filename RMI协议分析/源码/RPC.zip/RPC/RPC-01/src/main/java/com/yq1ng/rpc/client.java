package com.yq1ng.rpc;

import com.yq1ng.common.User;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;

public class client {
    public static void main(String[] args) throws Exception {

        //  创建对象，写入需要查询的id
        Socket socket = new Socket("127.0.0.1", 8888);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        DataOutputStream dataOutputStream = new DataOutputStream(byteArrayOutputStream);
        dataOutputStream.writeInt(888);

        //  转为二进制，清除缓存（否则会下次转二进制为空）
        socket.getOutputStream().write(byteArrayOutputStream.toByteArray());
        socket.getOutputStream().flush();

        //  获取server返回值
        DataInputStream dataInputStream = new DataInputStream(socket.getInputStream());
        int id = dataInputStream.readInt();
        String name = dataInputStream.readUTF();
        User user = new User(id,name);

        System.out.println(user);

        dataOutputStream.close();
        socket.close();
    }
}
