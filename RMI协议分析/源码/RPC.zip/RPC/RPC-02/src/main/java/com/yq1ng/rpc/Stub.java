package com.yq1ng.rpc;

import com.yq1ng.common.User;
import com.yq1ng.common.UserService;

import java.io.DataInputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.net.Socket;

public class Stub {
    public static UserService getStub() {
        InvocationHandler handler = new InvocationHandler() {

            public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {

                Socket socket = new Socket("127.0.0.1", 8888);

                ObjectOutputStream objectOutputStream = new ObjectOutputStream(socket.getOutputStream());

                String methodName = method.getName();
                Class[] parameterTypes = method.getParameterTypes();
                objectOutputStream.writeUTF(methodName);
                objectOutputStream.writeObject(parameterTypes);
                objectOutputStream.writeObject(args);
                objectOutputStream.flush();

                ObjectInputStream objectInputStream = new ObjectInputStream(socket.getInputStream());
                User user = (User) objectInputStream.readObject();

                objectOutputStream.close();
                socket.close();
                return user;
            }
        };
        Object object = Proxy.newProxyInstance(UserService.class.getClassLoader(),
                new Class[] {UserService.class},
                handler);
        return (UserService) object;
    }
}
