package com.yq1ng.rpc;

import com.yq1ng.common.UserService;

public class client {
    public static void main(String[] args) {
        UserService service = Stub.getStub();
        System.out.println(service.findUserById(666));
        System.out.println(service.findUserByName("yq1ng"));
    }
}
