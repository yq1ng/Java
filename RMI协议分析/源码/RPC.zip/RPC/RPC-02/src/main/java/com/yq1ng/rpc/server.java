package com.yq1ng.rpc;

import com.yq1ng.common.User;
import com.yq1ng.common.UserService;
import com.yq1ng.common.UserServiceImpl;

import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.net.ServerSocket;
import java.net.Socket;

public class server {
    private static boolean is_running = true;

    public static void main(String[] args) throws Exception {

        ServerSocket serverSocket = new ServerSocket(8888);

        while (is_running) {
            System.out.println("服务端已启动，正在监听 8888 端口，等待客户端连接...");
            Socket socket = serverSocket.accept();
            System.out.println("捕获到客户端请求...");
            process(socket);
            socket.close();
        }
        serverSocket.close();
    }

    private static void process(Socket socket) throws Exception {

        //  接收client请求参数
        InputStream in = socket.getInputStream();
        OutputStream out = socket.getOutputStream();
        ObjectInputStream objectInputStream = new ObjectInputStream(in);
        ObjectOutputStream objectOutputStream = new ObjectOutputStream(out);

        String methodName = objectInputStream.readUTF();
        Class[] parameterTypes = (Class[]) objectInputStream.readObject();
        Object[] args = (Object[]) objectInputStream.readObject();

        System.out.println("客户端请求方法为：" + methodName);

        UserService userService = new UserServiceImpl();
        Method method = userService.getClass().getMethod(methodName, parameterTypes);
        User user = (User) method.invoke(userService, args);

        objectOutputStream.writeObject(user);
        objectOutputStream.flush();
    }
}
