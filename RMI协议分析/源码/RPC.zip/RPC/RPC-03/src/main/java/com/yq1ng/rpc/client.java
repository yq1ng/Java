package com.yq1ng.rpc;

import com.yq1ng.common.StudentService;
import com.yq1ng.common.UserService;

public class client {
    public static void main(String[] args) {
        StudentService studentService = (StudentService) Stub.getStub(StudentService.class);
        System.out.println(studentService.findStudentById(888));
        System.out.println(studentService.findStudentByName("yq1ng"));
        UserService userService = (UserService) Stub.getStub(UserService.class);
        System.out.println(userService.findUserById(888));
        System.out.println(userService.findUserByName("yq1ng"));
    }
}
