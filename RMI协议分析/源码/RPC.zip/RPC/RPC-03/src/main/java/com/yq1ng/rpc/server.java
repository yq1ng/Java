package com.yq1ng.rpc;

import com.yq1ng.common.StudentServiceImpl;
import com.yq1ng.common.UserServiceImpl;

import java.io.*;
import java.lang.reflect.Method;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;

public class server {
    private static boolean is_running = true;
    private static final HashMap<String, Object> REGISTRY_MAP = new HashMap();

    public static void main(String[] args) throws Exception {

        // 向注册中心注册服务
        REGISTRY_MAP.put("com.yq1ng.common.UserService", new UserServiceImpl());
        REGISTRY_MAP.put("com.yq1ng.common.StudentService", new StudentServiceImpl());

        ServerSocket serverSocket = new ServerSocket(8888);

        while (is_running) {
            System.out.println("服务端已启动，正在监听 8888 端口，等待客户端连接...");
            Socket socket = serverSocket.accept();
            System.out.println("捕获到客户端请求...");
            process(socket);
            socket.close();
        }
        serverSocket.close();
    }

    private static void process(Socket socket) throws Exception {

        //  接收client请求参数
        InputStream in = socket.getInputStream();
        OutputStream out = socket.getOutputStream();
        ObjectInputStream objectInputStream = new ObjectInputStream(in);
        ObjectOutputStream objectOutputStream = new ObjectOutputStream(out);

        //  获取服务名、方法名、形参类型、参数
        String serviceName  = objectInputStream.readUTF();
        String methodName = objectInputStream.readUTF();
        Class[] parameterTypes = (Class[]) objectInputStream.readObject();
        Object[] args = (Object[]) objectInputStream.readObject();

        System.out.println("代理接口为：" + serviceName);
        System.out.println("客户端请求方法为：" + methodName);

        //  从注册中心获取服务
        Object serverObject = REGISTRY_MAP.get(serviceName);

        //  通过反射调用服务方法
        Method method = serverObject.getClass().getMethod(methodName, parameterTypes);
        Object resp = method.invoke(serverObject, args);

        objectOutputStream.writeObject(resp);
        objectOutputStream.flush();
    }
}
