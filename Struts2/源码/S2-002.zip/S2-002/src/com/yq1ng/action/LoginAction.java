package com.yq1ng.action;

import com.opensymphony.xwork2.ActionSupport;

/**
 * @program: S2-001
 * @description:
 * @author: yq1ng
 * @create: 2021-04-21 21:24
 **/

public class LoginAction extends ActionSupport {
    private String username = null;
    private String password = null;
    private String url = null;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getUsername() {
        return this.username;
    }

    public String getPassword() {
        return this.password;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String execute() throws Exception {
        return "success";
    }
}